﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace AT1
{
    class TaskAllocation
    {
        public string CffFilename { get; set; }

        List<string> Errors { get; set; }

        //Potential Option for Resources - Keeping for future reference as it seems useful but not currently using
        public static readonly string[] KEYWORDS = { "ALLOCATIONS-DATA", "ALLOCATION-ID" };

        //This is an example to see how those would be utilised
        private void GetAllocationData(string line)
        {
            if (line == KEYWORDS[0])
            {
                Console.WriteLine("This line contains the Allocation data");
            }
            if (line == KEYWORDS[1])
            {
                Console.WriteLine("This line contains the Allocation ID");
                Console.WriteLine("The following are the allocations");
            }
        }

        public Boolean GetCffFilename(string taffFilename)
        {
            CffFilename = null;
            Errors = new List<string>();

            StreamReader sr = new StreamReader(taffFilename);
            
            while(!sr.EndOfStream)
            {
                string line = sr.ReadLine();
                line = line.Trim();

                if (line.StartsWith(Resource1.configFileKeyword))
                {
                    string[] data = line.Split('=');
                    
                    if (data.Length==2)
                    {
                        CffFilename = data[1].Trim('"');

                        if (CffFilename.Length > 0)
                        {
                            if (CffFilename.IndexOfAny(Path.GetInvalidFileNameChars())==-1)
                            {
                                string path = Path.GetDirectoryName(taffFilename);
                                CffFilename = path + Path.DirectorySeparatorChar + CffFilename;
                            }
                            else
                            {
                                Errors.Add("invalid characters");
                            }
                        }
                        else
                        {
                            Errors.Add("no filename found");
                        }

                    }
                    else
                    {
                        Errors.Add("no value for keyword");
                    }
                }
                else
                {
                    GetAllocationData(line);
                }
            }

            sr.Close();
            return (Errors.Count == 0);
        }
        public Boolean Validate(string taffFilename)
        {
            Errors = new List<string>();
            return (Errors.Count == 0);
        }
        public string[] GetAllocationsData(string openPath)
        {
            string[] allocationData = null;

            StreamReader sr = new StreamReader(openPath);

            while (!sr.EndOfStream)
            {
                string line = sr.ReadLine();
                line = line.Trim();

                if (line.StartsWith(Resource1.AllocInfo))
                {
                    string[] data = line.Split('=');

                    if (data.Length == 2)
                    {
                        allocationData = data[1].Split(',');

                        return allocationData;
                    }
                    else
                    {
                        Errors.Add("no value for keyword");
                    }
                }
            }

            sr.Close();
            return allocationData;
        }
        public List<string> CalculateAllocations (string openPath, string[] AllocationData, List<string> Print)
        {
            return Print;
        }
    }
}
