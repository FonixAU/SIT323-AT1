﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace AT1
{
    public partial class Allocations : Form
    {
        public string[] TaffFile { get; set; }
        public Allocations()
        {
            InitializeComponent();
        }

        public DialogResult selected;

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox aboutbox = new AboutBox();
            aboutbox.ShowDialog();
        }

        private void errorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewErrors viewForm = new ViewErrors();
            viewForm.WebBrowser.DocumentText = @"<h1>Errors in data files</h1>";

            viewForm.Show();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog1.ShowDialog();

            if (result == DialogResult.OK)
            {
                string taffFilename = openFileDialog1.FileName;

                Configuration configuration = new Configuration();
                TaskAllocation taskAllocation = new TaskAllocation();

                if (taskAllocation.GetCffFilename(taffFilename))
                {
                    if (taskAllocation.Validate(taffFilename) && configuration.Validate(taskAllocation.CffFilename))
                    {
                        Console.WriteLine("The Log File: " + configuration.LogFilename);
                        selected = result;
                        MessageBox.Show(configuration.LogFilename);

                        allocateToolStripMenuItem.Enabled = true;
                    }
                }
            }
        }
        private string FinalPrinter(List<string> Print)
        {
            string FinalPrint = null;
            for (int i = 0; i < (Print.Count); i++)
            {
                FinalPrint = FinalPrint + Print[i];
            }
            return FinalPrint;
        }
        public string ValidateTAFFForPrint(string[] TaffFile, string[] AllocationData, string openPath, string TaffName)
        {
            Configuration configuration = new Configuration();
            string taffprint = "validation failed";
            // for later : bool Valid = configuration.TestValidList(ValidList);
            List<string> alloc_ID = configuration.GetAllocIDs(openPath, AllocationData);

            if (alloc_ID.Count() == Convert.ToInt32(AllocationData[0]))
            {
                StreamReader sr = new StreamReader(openPath);
                while (!sr.EndOfStream)
                {

                    string line = sr.ReadLine();
                    line = line.Trim();
                    List<string> data = new List<string>();
                    if ()
                    {

                    }
                    if (line.StartsWith("0") || line.StartsWith("1"))
                    {
                        string[] temp = line.Split(',');
                        for (int i = 0; i < temp.Length; i++)
                        {
                            data.Add(temp[i]);
                        }


                        if (data.Count() == (Convert.ToInt32(AllocationData[0]) * Convert.ToInt32(AllocationData[1]) * Convert.ToInt32(AllocationData[0])))
                        {
                            return taffprint = "(" + TaffName + ") is valid";
                        }
                    }
                }
                sr.Close();
            }
            return taffprint = "(" + TaffName + ") is invalid";
        }
        public void getTaffFile(string openPath)
        {
            StreamReader sr = new StreamReader(openPath);
            while (!sr.EndOfStream)
            {
                TaffFile = sr.ReadToEnd();
            }
        }
        private void allocateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TaskAllocation taskAllocation = new TaskAllocation();
            Configuration configuration = new Configuration();
            List<string> Print = new List<string>();

            string openPath = openFileDialog1.FileName;
            getTaffFile(openPath);
            string CffFilename = configuration.GetFileNames(openPath) + ".cff";
            string TaffFilename = configuration.GetFileNames(openPath) + ".taff";
            string[] AllocationData = taskAllocation.GetAllocationsData(openPath);
            string TaffValid = ValidateTAFFForPrint(TaffFile, AllocationData, openPath, TaffFilename);

            Print.Add(@"<h2>Allocations file " + TaffValid + "</ h2 >");
            Print.Add(@"<h2>Configuration file (" + CffFilename + ") is valid</ h2 >");

            Print.Add(@"<p>Testing:" + AllocationData[0] + ","+ AllocationData[1] + "," + AllocationData[2] + "</p>" );

            string FinalPrint = FinalPrinter(Print);
            webBrowser1.DocumentText = FinalPrint;
        }
    }
}
