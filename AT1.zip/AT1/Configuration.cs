﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;

namespace AT1
{
    class Configuration
    {
        public string LogFilename { get; set; }
        public List<string> Errors { get; set; }

        public string GetFileNames(string openPath)
        {
            StreamReader sr = new StreamReader(openPath);
            string CffFilename = null;

            while (!sr.EndOfStream)
            {
                string line = sr.ReadLine();
                line = line.Trim();

                if (line.StartsWith(Resource1.configFileKeyword))
                {
                    string[] data = line.Split('=');

                    if (data.Length == 2)
                    {
                        CffFilename = data[1].Trim('"');
                        string[] name = CffFilename.Split('.');
                        CffFilename = name[0].Trim('.');
                    }
                    else
                    {
                        Errors.Add("no value for keyword");
                    }
                }
            }

            sr.Close();
            return CffFilename;
        }
        public bool TestValidList(List<bool> ValidList)
        {
            for (int i = 0; i < ValidList.Count(); i++)
            {
                if (!ValidList[i])
                {
                    
                    return false;
                }
            }
            return true;
        }
        public List<string> GetAllocIDs(string openPath, string[] AllocationData)
        {
            List<string> alloc_ID = new List<string>();

            StreamReader sr = new StreamReader(openPath);

            while (!sr.EndOfStream)
            {
                string line = sr.ReadLine();
                line = line.Trim();

                if (line.StartsWith(Resource1.AllocID))
                {
                    string[] data = line.Split('=');

                    if (data.Length == 2)
                    {
                        alloc_ID.Add(data[1]);
                    }
                    else
                    {
                        Errors.Add("no value for keyword");
                    }
                }
                
            }
            sr.Close();
            Console.WriteLine(alloc_ID);
            return alloc_ID;
        }
        public Boolean Validate(string cffFilename)
        {
            LogFilename = null;
            Errors = new List<string>();

            StreamReader sr = new StreamReader(cffFilename);

            while (!sr.EndOfStream)
            {
                string line = sr.ReadLine();
                line = line.Trim();

                if (line.Length == 0)
                {

                }
                else if (Regex.IsMatch(line, Resource1.comment_pattern))
                {

                }
                else if (line.StartsWith("DEFAULT-LOGFILE"))
                {
                    string[] data = line.Split('=');
                    if (data.Length == 2)
                    {
                        LogFilename = data[1].Trim('"');

                        if (LogFilename.IndexOfAny(Path.GetInvalidFileNameChars()) == -1)
                        {
                            string path = Path.GetDirectoryName(cffFilename);
                            LogFilename = path + Path.DirectorySeparatorChar + LogFilename;
                        }
                        else
                        {
                            Errors.Add("no filename found");
                        }
                    }
                    else
                    {
                        Errors.Add("no value for keyword");
                    }
                }
            }
            sr.Close();

            return (Errors.Count == 0);
        }
    }
}
